/* Topic-wise PPS practice bank. Answers are intentionally short so students can self-check. */
const units = [
{title:'Unit 1: Introduction to Programming & Computer Fundamentals',topics:[
['Computer system components','CPU, memory, input/output and storage',[
['What are the four broad parts of a computer system?','Processor (CPU), main memory, input devices and output devices; storage and software support the system too.'],['Differentiate primary and secondary memory.','Primary memory is directly used by the CPU and is generally faster; secondary storage keeps data long-term and is usually larger.'],['What is the role of the CPU?','It fetches, decodes and executes instructions, performing arithmetic, logic and control operations.'],['Give two input and two output devices.','Input: keyboard and mouse. Output: monitor and printer.'],['How are RAM and ROM different?','RAM is read/write working memory and is typically volatile; ROM is non-volatile memory used to retain firmware or fixed instructions.']]],
['System software and translators','OS, assembler, compiler, interpreter, loader and linker',[
['Name three basic functions of an operating system.','Process/CPU management, memory management, file management and device/input-output management are common functions.'],['What does an assembler do?','It translates assembly-language instructions into machine/object code.'],['Compiler vs interpreter: what is the key difference?','A compiler translates a program before execution; an interpreter processes and executes instructions through its runtime, often step by step.'],['What are linker and loader responsible for?','The linker combines object files/libraries and resolves references; the loader places the executable into memory to run.'],['Why is an operating system called system software?','It manages hardware resources and provides services/interface for applications.']]],
['Algorithms, flowcharts and pseudocode','Problem-solving steps, symbols and control flow',[
['What is an algorithm?','A finite, unambiguous sequence of steps to solve a problem.'],['Name common flowchart symbols and their meanings.','Oval: start/end; rectangle: process; parallelogram: input/output; diamond: decision; arrows: flow direction.'],['Write pseudocode to add two numbers.','START; INPUT a, b; sum ← a + b; OUTPUT sum; STOP.'],['Why should an algorithm be finite?','It must terminate after a finite number of steps rather than continue indefinitely.'],['When is a decision diamond used?','When a condition branches the flow into alternatives, such as Yes/No or True/False.']]],
['C program structure and build process','Headers, main, compile/run and error types',[
['What is the purpose of #include <stdio.h>?','It makes declarations for standard input/output functions such as printf and scanf available.'],['What is the usual entry point of a hosted C program?','The main function, commonly written as int main(void) or int main(int argc, char **argv).'],['Put the basic build steps in order.','Preprocessing, compilation, assembly and linking; the resulting executable is then loaded and run.'],['Syntax error vs logical error?','A syntax error violates language grammar; a logical error allows execution but produces an incorrect result.'],['Object code vs executable code?','Object code is a compiled/assembled module that may still need linking; executable code has been linked into a runnable program for its target environment.']]]]},
{title:'Unit 2: Arithmetic Expressions, Conditionals & Loops',topics:[
['Tokens, data types, variables and constants','int, float, char, double, declarations and memory',[
['What is a token in C?','A smallest meaningful lexical unit, such as a keyword, identifier, constant, string literal or operator.'],['Choose a type for a whole number, decimal value and single character.','Typically int, float or double, and char respectively.'],['What is a variable?','A named object whose stored value can change during program execution.'],['What is a constant?','A value that is not intended to change; C supports literals and const-qualified objects, among other forms.'],['What does initialization mean?','Giving an object its initial value at the time it is defined.']]],
['Operators, expressions and conversions','Arithmetic, relational, logical, assignment, bitwise, ternary, precedence',[
['What is the value of 7 / 2 when both operands are int?','3, because integer division discards the fractional part.'],['What is the difference between = and ==?','= assigns a value; == tests equality.'],['What does the conditional operator condition ? x : y do?','It evaluates condition and produces x when true, otherwise y.'],['What do && and || mean?','Logical AND and logical OR; both short-circuit when the result is already determined.'],['What is type casting? Give an example.','An explicit type conversion, e.g. (double)a / b to request floating-point division.']]],
['Conditional branching','if, if-else, nested if, switch, break, continue and goto',[
['When would you use if-else?','To choose between two paths based on a condition.'],['What does break do inside a switch?','It exits the switch; without it, execution may fall through to subsequent case labels.'],['Can switch directly select a case using a string in standard C?','No. switch controlling expressions must have an appropriate integer type; strings are not supported as case labels.'],['What does continue do inside a loop?','It skips the remaining statements in the current iteration and proceeds to the next iteration check/update.'],['Why should goto be used cautiously?','Unstructured jumps can make control flow harder to understand and maintain.']]],
['Loops and iteration','for, while, do-while and nested loops',[
['Which loop always executes its body at least once?','do-while, because its condition is checked after the body.'],['When is a for loop especially convenient?','When initialization, loop condition and update can be expressed together, often for counted iteration.'],['How is while different from do-while?','while checks before the body; do-while checks after the body.'],['How many times does for (int i=0; i<4; i++) run?','Four times, for i equal to 0, 1, 2 and 3.'],['What is a nested loop?','A loop inside another loop; commonly used for grids, tables and matrix processing.']]]]},
{title:'Unit 3: Arrays & Basic Algorithms',topics:[
['One-dimensional arrays','Declaration, initialization, indexing and traversal',[
['How do you declare an array of 10 integers?','int values[10];'],['What is the first valid index of a C array?','0. For an array of length n, valid indices are 0 through n-1.'],['What happens if you access an array out of bounds?','The behaviour is undefined; C does not automatically check array bounds.'],['How can you traverse an array of n elements?','Use a loop with i from 0 while i < n and access array[i].'],['Write an expression for the third element of int a[5].','a[2].']]],
['Two-dimensional arrays and matrices','Rows, columns, memory layout, addition and multiplication',[
['Declare a 3-row, 4-column integer array.','int matrix[3][4];'],['When can two matrices be added?','When they have the same number of rows and columns.'],['What condition allows matrix A (m×n) times B (p×q)?','The inner dimensions must match: n = p; result dimensions are m×q.'],['How is a typical C 2D array laid out in memory?','In row-major order: elements of each row are contiguous.'],['What is the formula for matrix addition?','For matching dimensions, C[i][j] = A[i][j] + B[i][j].']]],
['Strings and string.h','Character arrays, null terminator and library functions',[
['What marks the end of a C string?','The null character, written as backslash-zero (\\0) in a string representation.'],['What does strlen(s) return?','The number of characters before the terminating null character, not counting it.'],['What does strcpy(destination, source) do?','Copies the source string, including its terminating null character, into destination; destination must have enough space.'],['What does strcmp(a, b) indicate?','It returns a negative value, zero or a positive value depending on lexicographic comparison.'],['What does strcat(destination, source) require?','Destination must already contain a valid string and have enough remaining space for source plus the null terminator.']]],
['Linear and binary search','Searching an item in a collection',[
['How does linear search work?','It checks elements one by one until the target is found or the list ends.'],['What must normally be true before binary search on an array?','The array must be sorted according to the order used by the search.'],['What is linear search worst-case time complexity?','O(n).'],['What is binary search worst-case time complexity on a sorted array?','O(log n).'],['If the middle value is smaller than the target in ascending order, which half remains?','The right half, excluding the middle element.']]],
['Sorting algorithms','Bubble, selection and insertion sort',[
['How does bubble sort work?','It repeatedly compares adjacent elements and swaps out-of-order pairs, moving large values toward the end.'],['What does selection sort select on each pass?','The smallest remaining element (for ascending order) and places it at the next position.'],['How does insertion sort build a sorted section?','It takes the next element and inserts it into the correct position among previously sorted elements.'],['Which of these three sorts is often effective for small or nearly sorted arrays?','Insertion sort is often effective for small or nearly sorted arrays.'],['What is the typical worst-case time complexity of bubble, selection and insertion sort?','Each is O(n²) in the typical comparison-based implementation.']]],
['Order of complexity and Big-O','Growth rate and simple algorithm analysis',[
['What does Big-O describe?','An asymptotic upper bound on how an algorithm’s resource use grows with input size.'],['What is the complexity of one loop from 0 to n-1 with constant work each time?','O(n).'],['What is the complexity of two independent nested loops each running n times?','O(n²), if the inner body does constant work.'],['What is the usual complexity of accessing array[i]?','O(1) for a valid index in a standard array.'],['Which grows more slowly for large n: O(n) or O(n²)?','O(n) grows more slowly.']]]]},
{title:'Unit 4: Functions, Recursion & Pointers',topics:[
['Functions and prototypes','Declaration, definition, call and parameters',[
['What is a function prototype?','A declaration that tells the compiler a function’s name, return type and parameter types before use.'],['Differentiate declaration and definition of a function.','A declaration introduces the function interface; a definition provides its body.'],['What does return do?','It ends the function and optionally passes a value back to the caller.'],['Does standard C pass ordinary arguments by reference?','No. C passes arguments by value; a pointer can be passed so the function can modify the pointed-to object.'],['Why divide a program into functions?','To improve modularity, reuse, testing and readability.']]],
['Call by value and pointer-based modification','Arguments, addresses and effects',[
['If a function receives int x, does changing x change the caller’s variable?','No; x is a local copy of the argument.'],['How can a function modify a caller’s integer?','Pass its address using an int pointer parameter and modify the pointed-to object.'],['What does a swap function need to receive to swap two caller variables?','Pointers to both variables, such as int *a and int *b.'],['What does &value produce?','The address of value.'],['What is a common mistake when using pointers as function parameters?','Dereferencing a null, uninitialized or otherwise invalid pointer.']]],
['Scope and storage classes','auto, extern, static and register',[
['What is the usual scope of a local variable declared inside a block?','From its declaration to the end of that block, subject to the language’s scope rules.'],['What does static do to a local variable’s lifetime?','It gives the object static storage duration, so its value persists between function calls.'],['What does extern commonly declare?','An object or function defined elsewhere, often in another translation unit.'],['What is the basic meaning of auto for a local variable?','It has automatic storage duration; this is also the default for ordinary block-scope local variables.'],['Does register guarantee that a variable is stored in a CPU register?','No. It is only a request/hint; modern compilers choose placement.']]],
['Recursion','Base case, factorial, Fibonacci and Tower of Hanoi',[
['What is the base case in recursion?','A condition that stops further recursive calls.'],['What is 5! (factorial)?','120, since 5×4×3×2×1 = 120.'],['Give the common recursive definition of factorial.','factorial(0) = 1; for n > 0, factorial(n) = n × factorial(n-1).'],['What are the first six Fibonacci numbers under the 0,1 starting convention?','0, 1, 1, 2, 3, 5.'],['What is the minimum number of moves for Tower of Hanoi with n disks?','2^n − 1, when the standard rules and optimal strategy are used.']]],
['Pointers and pointer arithmetic','Address-of, dereference, arrays and self-reference',[
['What does int *p declare?','p is a pointer to int.'],['If p points to x, what does *p mean?','The object/value that p points to; it can be read or modified when valid.'],['What does p + 1 mean for an int pointer?','A pointer to the next int element position, scaled by sizeof(int), within the same array object or one past it.'],['How are array indexing and pointer arithmetic related?','a[i] is defined in terms of *(a + i) for ordinary array indexing.'],['What is a self-referential structure?','A structure that contains a pointer to a structure of the same type, often used for linked lists.']]],
['Dynamic memory allocation','malloc, calloc, realloc and free',[
['Which header declares malloc and free?','<stdlib.h>.'],['What is the difference between malloc and calloc?','malloc allocates a block without initializing its contents; calloc allocates an array block and initializes its bytes to zero.'],['What must you check after malloc?','Check whether the returned pointer is NULL before using the allocation.'],['Why use a temporary pointer with realloc?','If realloc fails for a nonzero requested size, it returns NULL and the original allocation remains valid; a temporary avoids losing its pointer.'],['What should happen after dynamically allocated memory is no longer needed?','Call free on the allocation exactly once and do not use the freed memory afterward.']]]]},
{title:'Unit 5: Structures, Union & File Handling',topics:[
['Structures and member access','struct definition, . and -> operators, arrays of structures',[
['What does a struct do?','It groups multiple named members, which may have different types, into one object type.'],['How do you access member marks of structure variable s?','s.marks'],['How do you access marks through pointer p to a structure?','p->marks, equivalent to (*p).marks.'],['What is an array of structures useful for?','Storing multiple records of the same shape, such as several students.'],['Can structure members have different data types?','Yes. A structure can group members of different types.']]],
['Unions','Shared storage and comparison with structures',[
['What is the main memory difference between struct and union?','Struct members have distinct storage within the object; union members share overlapping storage.'],['How much storage does a union require?','Enough for its largest member, with alignment and padding as required by the implementation.'],['Can all union members independently hold separate values at the same time?','No; they share storage, so writing one member can overwrite the representation of another.'],['Give one use for a union.','Representing one of several alternative data forms when only one variant is active at a time.'],['What is the dot operator used for?','Accessing a member through a structure or union object.']]],
['Text and binary file handling','FILE, fopen modes, reading, writing and closing',[
['What does fopen return?','A FILE pointer on success, or NULL on failure.'],['What is the difference between modes r, w and a?','r opens for reading an existing file; w creates or truncates for writing; a opens for appending, creating if needed.'],['What do r+ and w+ generally allow?','Reading and writing; r+ requires an existing file, while w+ creates or truncates a file.'],['Why should fclose be called?','To close the stream and flush buffered output as required.'],['Text vs binary file: what is the broad difference?','Text mode treats data as text and may translate line endings; binary mode reads/writes bytes without text translations where the implementation distinguishes them.']]],
['File I/O functions and random access','fprintf, fscanf, fgets, fputs, fread, fwrite, fseek, ftell, rewind',[
['What are fprintf and fscanf used for?','Formatted output to a stream and formatted input from a stream, respectively.'],['When is fgets useful?','Reading a line or bounded sequence of characters into a buffer, including spaces.'],['What do fread and fwrite handle?','Reading and writing blocks of data as bytes/items, often used for binary files.'],['What does ftell report?','The current file-position indicator as a long integer value, or -1L on failure.'],['What do fseek and rewind do?','fseek changes the stream position; rewind returns to the beginning and clears the stream error/EOF indicators.']]],
['Preprocessor directives','include, define and conditional compilation',[
['What does #include do?','It directs the preprocessor to include the contents of a header or specified file.'],['What is a macro defined with #define?','A preprocessor replacement rule, commonly used for symbolic constants or function-like macros.'],['Why parenthesize macro parameters and the full expression?','To reduce unexpected precedence interactions when the macro is expanded.'],['What are #ifdef and #ifndef used for?','They conditionally include code depending on whether a macro is defined or not defined.'],['What is a common use of conditional compilation?','Platform-specific code, optional debug code or preventing repeated header inclusion.']]]]}
];

const syllabusRoot = document.getElementById('syllabus');
const searchInput = document.getElementById('topic-search');
const completedKey = 'arshPpsCompletedTopicsV1';
let completed = {};
try { completed = JSON.parse(localStorage.getItem(completedKey) || '{}') || {}; } catch (_) { completed = {}; }
const totalTopics = units.reduce((sum, unit) => sum + unit.topics.length, 0);
document.getElementById('total-count').textContent = totalTopics;
document.getElementById('topic-stat').textContent = `${totalTopics} topics · ${totalTopics * 5} questions`;

function esc(text) { return String(text).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch])); }
function render() {
  syllabusRoot.innerHTML = '';
  units.forEach((unit, unitIndex) => {
    const section = document.createElement('section');
    section.className = 'unit-card';
    section.dataset.unit = unit.title.toLowerCase();
    section.innerHTML = `<div class="unit-heading"><div><h2>${esc(unit.title)}</h2><p class="unit-intro">Work through each topic and reveal answers only after attempting the questions.</p></div><span class="unit-tag">UNIT ${unitIndex + 1}</span></div><div class="topic-grid"></div>`;
    const grid = section.querySelector('.topic-grid');
    unit.topics.forEach((topic, topicIndex) => {
      const id = `u${unitIndex}t${topicIndex}`;
      const card = document.createElement('article');
      card.className = 'topic-card'; card.dataset.search = `${unit.title} ${topic[0]} ${topic[1]} ${topic[2].map(q=>q[0]).join(' ')}`.toLowerCase(); card.dataset.topicId = id;
      card.innerHTML = `<h3>${esc(topic[0])}</h3><p>${esc(topic[1])}</p><span class="topic-count">5 questions</span><details><summary>Practise questions and reveal answers</summary><div class="question-list">${topic[2].map((q, i) => `<div class="question"><p><strong>Q${i+1}.</strong> ${esc(q[0])}</p><button type="button" class="answer-btn" aria-expanded="false">Reveal answer</button><div class="answer"><strong>Answer:</strong> ${esc(q[1])}</div></div>`).join('')}</div></details><label class="topic-done"><input type="checkbox" class="done-checkbox" ${completed[id] ? 'checked' : ''}> Mark topic complete</label>`;
      grid.appendChild(card);
    });
    syllabusRoot.appendChild(section);
  });
  updateProgress();
}
function updateProgress() {
  const count = Object.values(completed).filter(Boolean).length;
  document.getElementById('completed-count').textContent = count;
  const pct = totalTopics ? Math.round(count / totalTopics * 100) : 0;
  document.getElementById('progress-fill').style.width = `${pct}%`;
  const bar = document.getElementById('progress-bar'); bar.setAttribute('aria-valuenow', String(pct));
}
syllabusRoot.addEventListener('click', event => {
  const btn = event.target.closest('.answer-btn');
  if (btn) {
    const answer = btn.nextElementSibling; const show = !answer.classList.contains('show');
    answer.classList.toggle('show', show); btn.textContent = show ? 'Hide answer' : 'Reveal answer'; btn.setAttribute('aria-expanded', String(show));
  }
});
syllabusRoot.addEventListener('change', event => {
  if (!event.target.matches('.done-checkbox')) return;
  const card = event.target.closest('.topic-card'); completed[card.dataset.topicId] = event.target.checked;
  try { localStorage.setItem(completedKey, JSON.stringify(completed)); } catch (_) {}
  updateProgress();
});
searchInput.addEventListener('input', () => {
  const query = searchInput.value.trim().toLowerCase(); let visible = 0;
  syllabusRoot.querySelectorAll('.topic-card').forEach(card => { const match = card.dataset.search.includes(query); card.hidden = !match; if (match) visible++; });
  syllabusRoot.querySelectorAll('.unit-card').forEach(unit => { const any = [...unit.querySelectorAll('.topic-card')].some(card => !card.hidden); unit.hidden = !any; });
  document.getElementById('empty-state').style.display = visible ? 'none' : 'block';
});
document.getElementById('expand-all').addEventListener('click', event => {
  const details = [...syllabusRoot.querySelectorAll('.topic-card:not([hidden]) details')];
  const shouldOpen = details.some(detail => !detail.open); details.forEach(detail => detail.open = shouldOpen);
  event.currentTarget.textContent = shouldOpen ? 'Collapse all questions' : 'Expand all questions';
});
document.getElementById('reset-progress').addEventListener('click', () => {
  if (!window.confirm('Reset all saved topic-completion progress on this browser?')) return;
  completed = {}; try { localStorage.removeItem(completedKey); } catch (_) {}
  syllabusRoot.querySelectorAll('.done-checkbox').forEach(input => input.checked = false); updateProgress();
});
render();
