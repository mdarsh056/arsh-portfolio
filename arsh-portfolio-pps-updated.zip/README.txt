ARSH.DEV PORTFOLIO

Files:
- index.html        Home page
- c-language.html  C language roadmap and code examples
- core-cs.html     Problem solving / core CS guide
- web-dev.html     HTML/CSS fundamentals guide
- styles.css       Shared responsive dark theme
- script.js        Small accessible mobile navigation and current-year footer

Run locally:
1. Extract all files into the same folder.
2. Open index.html in a modern browser.
3. Keep the HTML, CSS, and JS files together so links and styling work.

No build tools, frameworks, external fonts, or CDNs are required.
The project cards are presented as portfolio concepts / learning projects; replace descriptions with real repository links and verified project status as your work develops.
